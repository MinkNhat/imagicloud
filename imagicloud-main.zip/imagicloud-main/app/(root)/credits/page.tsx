import React from 'react'

const CreditPage = () => {
  return (
    <div>CreditPage</div>
  )
}

export default CreditPage