import React from 'react'

const AddTransformationTypePage = () => {
  return (
    <div>AddTransformationTypePage</div>
  )
}

export default AddTransformationTypePage