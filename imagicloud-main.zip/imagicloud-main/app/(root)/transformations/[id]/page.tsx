import React from 'react'

const TransformationsPage = () => {
  return (
    <div>TransformationsPage</div>
  )
}

export default TransformationsPage