const Home = () => {
  return (
    <div>
      <p>Home Page</p>
    </div>
  )
}

export default Home